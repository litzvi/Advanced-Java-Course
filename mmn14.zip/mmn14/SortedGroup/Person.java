/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class Person implements Comparable<Person> {
    
    private String name;
    private int id;
    private int birthYear;
    
    public Person(String name, int id, int birthYear){
        this.name = name;
        this.id = id;
        this.birthYear = birthYear;
    }
    
    @Override
    public String toString() {
        return String.format("Name: %s ID: %d Year of Birth: %d%n", 
                name, id, birthYear);
    }

    @Override
    public int compareTo(Person t) {
        return this.birthYear - t.birthYear;
    }
}
