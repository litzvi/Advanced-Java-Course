
import java.util.ArrayList;
import java.util.Iterator;

/*
 * A Sorted Group with the elements in acending order.
*/

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class SortedGroup <T extends Comparable<T>> {
    
    private ArrayList<T> array;
    
    //Constroctur
    public SortedGroup() {
        array = new ArrayList<T>();
    }
    
    // Adds the element to the group maintaining the order.
    public void add(T element) {
        int i = binarySearch(element);
        if(i < 0) {
            i = - (i + 1);
        }
        array.add(i, element);
    }
    
    /*
    * Removes all elements that are equal to the given element.
    * Returns the number of elements removed from the group.
    */
    public int remove(T element) {
        int i = binarySearch(element);
        if(i < 0)
            return 0;
        
        //find the first apearence of elemnt in the array
        while(i > 0 && element.compareTo(array.get(i - 1)) == 0) {
            i--;
        }
        int removed = 0;
        while(i < array.size() && element.compareTo(array.get(i)) == 0) {
            array.remove(i);
            removed++;
        }
        return removed;
    }
    
    // Returns an Iterator over the group.
    public Iterator<T> iterator() {
        return array.iterator();
    }
    
    @Override
    public String toString() {
        return array.toString();
    }
    
    /*
    * Finds the location of an element that equals the given one in the group.
    * If dosen't exist returns the negative location of where it should be 
    * minus 1.
    */
    private int binarySearch(T element){
        
        int low = 0, high = array.size() - 1;
        int pivot = 0, compare = 0;
        while(low <= high) {
            pivot = (high + low) / 2;
            compare = element.compareTo(array.get(pivot));
            if(compare == 0)
                return pivot;
            else if(compare < 0) {
                high = pivot - 1;
            }
            else {
                low = pivot + 1;
            }            
        }
        
        if(compare > 0) {
            pivot++;
        }
        return -(pivot + 1);
        
    }
}
