
import java.util.Iterator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class SubGroup {
    
    //Returns a new group with the elements smaller than x.
    public static <T extends Comparable<T>> 
        SortedGroup<T> reduce(SortedGroup<T> sGroup, T x) {
            
            SortedGroup<T> subGroup = new SortedGroup<>();
            Iterator<T> it = sGroup.iterator();
            while(it.hasNext()) {
                T element = it.next();
                if(element.compareTo(x) < 0) {
                    subGroup.add(element);
                }
                else {
                    return subGroup;
                }
            }
            return subGroup;
    }
    
}
