/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class GroupTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SortedGroup<Person> sGroup = new SortedGroup<>();
        Person p1 = new Person("An", 125524, 1980);        
        Person p2 = new Person("Eli", 465464, 1986);        
        Person p3 = new Person("Zvi", 845465, 1983);        
        Person p4 = new Person("Ahron", 8453, 1960);        
        Person p5 = new Person("Isreal", 125524, 1948);
        Person p6 = new Person("Sarha", 125524, 1960);
        Person p7 = new Person("Young", 125524, 2000);
        Person p8 = new Person("Child", 125524, 2007);
        Person p9 = new Person("Baby", 125524, 2016);
        Person p10 = new Person("NewBorn", 125524, 2017);
        sGroup.add(p1);
        sGroup.add(p2);
        sGroup.add(p1);
        sGroup.add(p9);
        sGroup.add(p3);
        sGroup.add(p1);
        sGroup.add(p3);
        sGroup.add(p7);
        sGroup.add(p2);
        sGroup.add(p4);
        sGroup.add(p10);
        sGroup.add(p8);
        sGroup.add(p9);
        sGroup.add(p6);
        sGroup.add(p5);
        sGroup.add(p6);        
        System.out.println("Full group:\n" + sGroup);
        
        sGroup.remove(p5);
        sGroup.remove(p2);
        sGroup.remove(p10);
        sGroup.remove(p10);
        
        System.out.println("Before impling reduce:\n" + sGroup);
        
        SortedGroup<Person> century20 = SubGroup.reduce(sGroup, p7);
        System.out.println("After impling reduce:\n" + sGroup);
        System.out.println("Only people from 20th century:\n" + century20);
    }
    
}
