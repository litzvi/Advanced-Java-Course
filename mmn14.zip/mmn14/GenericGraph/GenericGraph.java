
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.HashMap;

/*
 * Generic Directed Graph
 * Implemented with a HashMap.
 * often.
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class GenericGraph <T> {
    
    private HashMap<T, HashSet<T>> nodes;
    
    // Constroctur
    public GenericGraph() {
        nodes = new HashMap<T, HashSet<T>>();
    }
    
    /*
    * Constroctur that recives an array of nodes and arcs.
    * every arc is represented by two folloing cells in the array.
    */
    public GenericGraph(T[] nodes, T[] arcs) {
        this();
        if(arcs.length % 2 != 0) {
            throw new IllegalArgumentException("Arcs array should be even");
        }
        
        for(T node: nodes) {
            addNode(node);
        }
        for(int i = 0; i < arcs.length; i += 2) {
            addArc(arcs[i], arcs[i+1]);
        }
    }
    
    /*
    * Adds a node to the graph, should only use immutable node.
    * throws an exception if the node already exists.
    */
    public void addNode(T node) {
        if(hasNode(node))
            throw new IllegalArgumentException("Node already Exists");
        else
            nodes.put(node, new HashSet<T>());
            
    }
    
    /*
    * Removes a node and all arcs containing it.
    */
    public void removeNode(T node) {
        if(!hasNode(node)) {
            throw new IllegalArgumentException("No such node: " + node);
        }            
            
        Iterator<HashSet<T>> it = nodes.values().iterator();
        while(it.hasNext()) {
            it.next().remove(node);
        }
        nodes.remove(node);
    }
    
    /*
    * Adds a directed arc from node1 to node2
    * returns an exception if one of the nodes don't exist 
    * or the arc already exists.
    */
    public void addArc(T node1, T node2) {
        if(!hasNode(node2)) {
            throw new IllegalArgumentException("No such node: " + node2);
        }  
        HashSet<T> arcs = nodes.get(node1);
        if(arcs == null) {
            throw new IllegalArgumentException("No such node: " + node1);
        }
        else {
            if(!arcs.add(node2))
                throw new IllegalArgumentException("The Arc already exists");
        }
        
    }
    
    /*
    * Removes an arc from the graph
    * throws an exception if dosen't exist.
    */
    public void removeArc(T node1, T node2) {
        HashSet<T> arcs = nodes.get(node1);
        if(arcs == null) {
            throw new IllegalArgumentException("No such node:" + node1);
        }
        else {
            if(!arcs.remove(node2))
                throw new IllegalArgumentException("The Arc dosen't exists");
        }
    }
    
    /*
    * returns true if the given node is in the graph.
    */
    public boolean hasNode(T node) {
        if(nodes.containsKey(node)) {
            return true;
        }
        return false;
    }
    
    /*
    * returns true if the arc already exists in the graph.
    */
    public boolean hasArc(T node1, T node2) {
        HashSet<T> arcs = nodes.get(node1);        
        if(arcs != null && arcs.contains(node2)) {
            return true;
        }
        return false;
    }
    
    @Override
    public String toString() {
        Object[] nodeList = new Object[nodes.size()];
        nodeList = nodes.keySet().toArray(nodeList);
        ArrayList<String> arcList = new ArrayList<>();
        for(Object obj: nodeList) {
            T node1 = (T)obj;
            HashSet<T> arcs = nodes.get(node1);  
            for(T node2: arcs) {
                arcList.add(String.format("(%s, %s)", node1, node2));                        
            }
        }
        return "Nodes:\n" + Arrays.toString(nodeList) + "\nArcs:\n" + arcList;
        
    }
    
    /*
    * Checks if the 2 graphes are the same - have the same nodes and arcs.
    */
    @Override
    public boolean equals(Object obj) {
        if(obj == null)
            return false;
        if(!(obj instanceof GenericGraph)) {
            return false;
        }
        GenericGraph graph = (GenericGraph)obj;
        
        return nodes.equals(graph.nodes);                
    }
}
