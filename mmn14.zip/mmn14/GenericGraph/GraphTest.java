/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class GraphTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Point p1 = new Point(0, 0);
        Point p2 = new Point(0, 1);
        Point p3 = new Point(1, 0);
        Point p4 = new Point(1, 1);
        Point p5 = new Point(2, 0);
        Point[] nodes = {p1, p2, p3, p4};
        Point[] arcs = {p1, p2, p1, p4, p3, p4, p4, p1};
        GenericGraph graph1 = new GenericGraph(nodes, arcs); 
        GenericGraph graph2 = new GenericGraph(nodes, arcs);
        System.out.printf("Are the graphes equal?: %b%n", graph1.equals(graph2));
        graph1.addNode(p5);
        graph1.addArc(p4, p3);
        graph1.addArc(p2, p4);
        graph1.addArc(p5, p2);
        System.out.println(graph1);      
      
        graph1.removeNode(p5);
        graph1.removeArc(p4, p3);
        System.out.println(graph1);
        
        System.out.printf("Are the graphes equal?: %b%n", graph1.equals(graph2));
        graph2.addArc(p2, p4);
        System.out.printf("Are the graphes equal?: %b%n", graph1.equals(graph2));
        
    }
    
}
