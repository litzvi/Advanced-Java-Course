/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lifegame;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class DrawGame extends JPanel{
    private LifeMatrix ourWorld;
    
    public DrawGame(LifeMatrix ourWorld){
        this.ourWorld = ourWorld;
    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        int size = ourWorld.dimension();
        int cellWidth = getWidth() / size;
        int cellHeight = getHeight() / size;
        for(int i=0; i < size; i++){
            for(int j=0; j < size; j++){
                if(ourWorld.isLiving(i, j)){
                    g.fillRect(j * cellWidth, i * cellHeight, cellWidth, cellHeight);
                }
                else{
                    g.drawRect(j * cellWidth, i * cellHeight, cellWidth, cellHeight);
                }
                
            }
        }
    }
}
