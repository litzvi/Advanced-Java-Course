/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lifegame;


import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class LifeGame {
    
    static final int DIMENSIONS = 10;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LifeMatrix ourWorld = new LifeMatrix(DIMENSIONS);
        DrawGame worldPic = new DrawGame(ourWorld);
        JFrame application = new JFrame();
        
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        application.add(worldPic);
        application.setSize(250, 250);
        application.setVisible(true);
        
        String message = "Would you like to move to next Generation?";
        int option = JOptionPane.showConfirmDialog(null, message);
        while(option == JOptionPane.YES_OPTION){
            ourWorld.moveGeneration();
            worldPic.repaint();
            option = JOptionPane.showConfirmDialog(null, message);
        }
    }
    
}
