/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lifegame;


import java.util.Random;
/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class LifeMatrix {
    private boolean[][] lifeM;
    
    // constructor recives the size of the life matrix
    public LifeMatrix(int size){
        lifeM = new boolean[size][size];
        fillRandom();
    }
    
    // fills the matrix with random values of life
    private void fillRandom(){
        Random randGen = new Random();
        for(int i = 0; i < lifeM.length; i++){
            for(int j = 0; j < lifeM.length; j++){
                lifeM[i][j] = randGen.nextBoolean();
            }
        }
            
    }
    
    // changes the life to the next generation as detirmened by the rules
    public void moveGeneration(){
        //saves the amount of live neighbors for every cell
        int lifeCount[][] = new int[lifeM.length][lifeM.length];
        for(int i = 0; i < lifeM.length; i++){
            for(int j = 0; j < lifeM.length; j++){
                for(int k = i-1; k <= i+1; k++){
                    for(int l = j-1; l <= j+1; l++){
                        if(k == i && l == j)
                            continue;
                        if(isLiving(k, l))
                            lifeCount[i][j]++;
                    }
                }
            }
        }
        int count;
        for(int i = 0; i < lifeM.length; i++){
            for(int j = 0; j < lifeM.length; j++){
                count = lifeCount[i][j];
                if(lifeM[i][j]){
                    if(count == 2 || count == 3)
                        continue;
                    else
                        lifeM[i][j] = false;
                        
                }
                else{
                    if(count == 3)
                        lifeM[i][j] = true;
                }
            }
        }
    }
    
    // returns if square i,j is living. returns false if it's an ileagal square
    public boolean isLiving(int i, int j){
        if((i < 0) || (j < 0) || (i >= lifeM.length) || (j >= lifeM.length))
            return false;
        return lifeM[i][j];
    }
    
    // returns the matrix dimensions
    public int dimension(){
        return lifeM.length;
    }
}
