/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordgame;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class Word {
    private final String word; // the chosen word
    private final char[] selectedWord; // the word showing the chosen letters
    private String nonUsedChars; // alphabet string of non used characters
    private int guesses;
    
    // constructor
    public Word(String word){
        this.word = word.toUpperCase();
        selectedWord = new char[word.length()];
        for(int i = 0; i < selectedWord.length; i++){
            selectedWord[i] = '-';
        }
        nonUsedChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        guesses = 0;
    }
    
    // adds the accurances of the given character to the gussed word
    public void chooseChar(char c){
        c = Character.toUpperCase(c);
        if(nonUsedChars.contains(String.valueOf(c))){
            nonUsedChars = nonUsedChars.replaceFirst(String.valueOf(c), "");
            guesses++;
        }
        else{
            return;
        }        
        int index = word.indexOf(c);
        while(index != -1){
            selectedWord[index] = c;
            index = word.indexOf(c, ++index);
        }        
    }
    
    // get the string with the chosen characters
    public String getFilledStr(){
        return String.valueOf(selectedWord);
    }
    
    // returns a string of not used characters
    public String getNonUsedChars(){
        return nonUsedChars;
    }
    
    // chaecks if the full word is gussed
    public boolean isWordFilled(){
        return getFilledStr().equals(word);
    }
    
    public int amountOfGuesses(){
        return guesses;
    }
}
