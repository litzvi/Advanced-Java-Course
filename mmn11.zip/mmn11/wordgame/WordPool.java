/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordgame;

import java.util.Random;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class WordPool {
    private static Random ranGen = new Random();
    private String[] words;
    
    // constructor that recieves a collection of words
    public WordPool(String[] words){
        this.words = words;
    }
    
    // returns a random word from the word pool
    public String randomWord(){
        int i = ranGen.nextInt(words.length);
        return words[i];
    }
}
