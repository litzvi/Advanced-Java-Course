/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordgame;

import javax.swing.JOptionPane;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class WordGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[] words = {"Hello", "Exercises", "program", "discovery", 
            "Stupid", "lovely", "disapointing", "trouble", "discusting", 
            "unfortunetly", "example"};
        
        Word gameWord = setUp(words);
        boolean toEnd = false;
        
        do{
            String input = JOptionPane.showInputDialog("Guessed word is:" + 
                    gameWord.getFilledStr() + 
                    "\nChoose from the following letters:" + 
                    gameWord.getNonUsedChars());
            if(input == null)// cancel option
                break;
            if(input.isEmpty())
                continue;
            char nextLetter = input.charAt(0);
            gameWord.chooseChar(nextLetter);
            if(gameWord.isWordFilled()){
                toEnd = true;
                int option = JOptionPane.showConfirmDialog(null, 
                        "Full word is: " + gameWord.getFilledStr() +
                        "\nU used " + 
                        Integer.toString(gameWord.amountOfGuesses()) + 
                        " gusses" + "\nWould you like to Play again?");
                if(option == JOptionPane.YES_OPTION){
                     gameWord = setUp(words);
                     toEnd = false;
                }
            }
        }while(!toEnd);
        
        
    }
    
    // chooses a word and initiates the word for the game
    private static Word setUp(String[] words){
        WordPool wordGen = new WordPool(words);
        Word gameWord = new Word(wordGen.randomWord());
        return gameWord;
    }
    
}
