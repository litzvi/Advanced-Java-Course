/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JFrame;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class PhilosopherTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PhilosopherPanel panel = new PhilosopherPanel();
        JFrame app = new JFrame("Philosophers Table");
        
        app.add(panel);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setSize(500, 500);
        app.setVisible(true);
    }
    
}
