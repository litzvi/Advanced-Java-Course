/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class Philosopher implements Runnable {
    
    private static final Random rand = new Random();
    private static final int MIN_EAT = 1000;
    private static final int MAX_EAT = 2000;
    private static final int MAX_THINK = 5000;
            
    private Sticks sticks;
    private int leftStick, rightStick;
    private boolean eating = false;
    
    /*
    * Constroctur. recives the set of sticks and the number Philosopher.
    */
    public Philosopher(Sticks sticks, int index) {
        this.sticks = sticks;
        if(index < 0 || index >= sticks.getNumberSticks()) {
            throw new IllegalArgumentException("No such Philosopher");
        }
        leftStick = index;
        rightStick = (leftStick + 1) % sticks.getNumberSticks();
    }

    @Override
    public void run() {
        try {
            while(true) {
                sticks.takeSticks(leftStick, rightStick);
                eating = true;
                Thread.sleep(rand.nextInt(MAX_EAT) + MIN_EAT);
                eating = false;
                sticks.leaveSticks(leftStick, rightStick);
                Thread.sleep(rand.nextInt(MAX_THINK));
                
            }

        } catch (InterruptedException ex) {
            System.out.println("Interrupted while eating");
            return;
        }
        finally {
            eating = false;
            sticks.leaveSticks(leftStick, rightStick);
        }
    }
    
    public boolean isEating() {
        return eating;
    }
    
    
}
