/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.JPanel;
import javax.swing.Timer;


/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class PhilosopherPanel extends JPanel implements ActionListener{
    
    private static final int NO_PHILOSOPHERS = 5;
    private static final int DELAY = 50;
    
    private final Sticks sticks = new Sticks(NO_PHILOSOPHERS);
    private final Philosopher[] philosophers = new Philosopher[NO_PHILOSOPHERS];
    private final Timer timer;
    
    public PhilosopherPanel() {
        ExecutorService executor = Executors.newCachedThreadPool();
        for(int i=0; i < NO_PHILOSOPHERS; i++) {
            philosophers[i] = new Philosopher(sticks, i);
            executor.execute(philosophers[i]);
        }
        executor.shutdown();
        timer = new Timer(DELAY, this);
        timer.start();
    }
    
    /*
    * Draw  philosophers. fill circle while eating.
    */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        int x = getWidth() / 4;
        int y = getHeight() / 4;
        double angle = 2 * Math.PI / NO_PHILOSOPHERS;
        for(int i=0; i < NO_PHILOSOPHERS; i++) {
            if(philosophers[i].isEating()) {
                g.fillOval((int)(x * (Math.sin(i * angle) + 1)), 
                        (int)(y * (Math.cos(i * angle) + 1)), x, y);
            }
            else {
                g.drawOval((int)(x * (Math.sin(i * angle) + 1)), 
                        (int)(y * (Math.cos(i * angle) + 1)), x, y);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        repaint();
    }

    
    
    
}
