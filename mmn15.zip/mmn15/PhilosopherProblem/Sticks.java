/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Arrays;


/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class Sticks {
    
    private final boolean[] sticks;
    
    //Constroctur. 
    public Sticks(int numSticks) {
        sticks = new boolean[numSticks];
        Arrays.fill(sticks, true);
    }
    
    /*
    * Takes the 2 requested chop sticks. Waits if occupied.
    */
    public void takeSticks(int left, int right) {
        if(left < 0 || left >= sticks.length || 
                right < 0 || right >= sticks.length) {
            throw new 
                IllegalArgumentException("Sticks are 0 to " + sticks.length);
        }
        
        synchronized(this) {
            while(!sticks[left] || !sticks[right]) {
                try {
                    wait();
                } catch (InterruptedException ex) {
                    System.out.println("Interupte while waiting");
                    return;
                }
                                
            }
            
            sticks[left] = sticks[right] = false;
        }
        
    }
    
    public void leaveSticks(int left, int right) {
        if(left < 0 || left >= sticks.length || 
                right < 0 || right >= sticks.length) {
            throw new 
                IllegalArgumentException("Sticks are 0 to " + sticks.length);
        }
        
        synchronized(this) {
            sticks[left] = sticks[right] = true;
            notifyAll();
        }
    }
    
    public int getNumberSticks() {
        return sticks.length;
    }
}
