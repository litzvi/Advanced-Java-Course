/*
 * Sums a list of integers conccurently.
 */

import java.util.Random;
import java.util.concurrent.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class ConcurrentListSumming {

    private static final int MAX_VAL = 100;
    public static Random gen = new Random();
    
    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        int listLength = 0, numberThreads = 0;
        String inLenMsg = "Enter List Length";
        String inThreadsMsg = "Enter numer of threads to run";
        
        //Recieve list length
        while(listLength <= 0) {
            String input = JOptionPane.showInputDialog(inLenMsg);
            try {
                listLength = Integer.parseInt(input);
            }
            catch(NumberFormatException ex) {                
                listLength = 0;
            }
            inLenMsg = "Wrong input: Enter positive list length.";
        }
        
        //Recieve number of threds
        while(numberThreads <= 0) {
            String input = JOptionPane.showInputDialog(inThreadsMsg);
            try {
                numberThreads = Integer.parseInt(input);
            }
            catch(NumberFormatException ex) {                
                numberThreads = 0;
            }
            inThreadsMsg = "Wrong input: Enter positive no of threads.";
        }
        
        //Create list
        Integer[] list = new Integer[listLength];
        for(int i=0; i < list.length; i++) {
            list[i] = gen.nextInt(MAX_VAL) + 1;
        }
        
        SummableList list2Sum = new SummableList(list, numberThreads);        
        ExecutorService executor = Executors.newCachedThreadPool();
        for(int i=0; i < numberThreads; i++) {
            executor.execute(new ListSummerizer(list2Sum));
        }
        executor.shutdown();
        boolean taskEnded = executor.awaitTermination(1, TimeUnit.SECONDS);
        
        //Final message
        if(taskEnded) {
            JOptionPane.showMessageDialog(null, "The Sum is: " 
                    + list2Sum.getItem().intValue());
        }
        else {
            JOptionPane.showMessageDialog(null, "Couldn't calculate.");
        }
    }
    
}
