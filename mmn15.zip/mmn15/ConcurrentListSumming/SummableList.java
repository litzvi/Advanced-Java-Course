/*
 * Represents a list of Number objects.
 * Soppurts removing 2 items, inserting an item, getting the last item
 * and a static method for summerizing 2 items.
 */

import java.util.Stack;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class SummableList {
    
    private static final int NO_TO_ADD = 2;
    private final Stack<Number> list;
    private final int runningThreads;
    private int waitingThreads = 0;
    
    //Constroctur
    public SummableList(Number[] list, int runningThreads) {
        this.list = new Stack<>();
        for(Number item: list) {
            this.list.push(item);
        }
        this.runningThreads = runningThreads;
    }
    
        
    /*
    * Removes 2 items from the list.
    * Returns a list with the 2 removed items.
    * If the list is left with one final item then returns null.
    */
    public synchronized Number[] remove2Items(Number[] items) {
        while(list.size() < NO_TO_ADD) {
            if(++waitingThreads == runningThreads) {
                notifyAll();
                return null;
            }            
            try {
                wait();
            } catch (InterruptedException ex) {
                System.out.println("Was Interupted\n");
            }
            waitingThreads--;
        }
        if(items == null || items.length < NO_TO_ADD) {
            throw new 
                IllegalArgumentException("Argument needs to be of length 2.");
        }
        items[0] = list.pop();
        items[1] = list.pop();
        return items;
    }
    
    /*
    * Inserts an item to the list.
    */
    public synchronized void insertItem(Number item) {
        list.push(item);
        notifyAll();
    }
    
    /*
    * Returns the int sum of 2 Number objects.
    */
    public static int addItems(Number item1, Number item2) {
        return item1.intValue() + item2.intValue();
    }
    
    /*
    * Returns 1 item from the list.
    * Can be used to get the final item.
    */
    public synchronized Number getItem() {
        return list.pop();
    }
}
