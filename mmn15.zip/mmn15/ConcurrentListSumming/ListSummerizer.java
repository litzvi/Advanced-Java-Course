/*
 * Summerizes a given Summable list conccurently.
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class ListSummerizer implements Runnable{
    
    SummableList list;
    
    public ListSummerizer(SummableList list) {
        this.list = list;
    }

    @Override
    public void run() {
        boolean calculating = true;
        Number[] items = new Integer[2];
        
        while(calculating) {
            items = list.remove2Items(items);
            if(items == null) {
                calculating = false;
            }
            else {
                int sum = SummableList.addItems(items[0], items[1]);
                list.insertItem(sum);
            }
            
        }
    }
    
}
