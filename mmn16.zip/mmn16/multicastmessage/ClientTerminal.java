
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class ClientTerminal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Client app = new Client();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
