
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.concurrent.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/*
 * 
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class Client extends JFrame implements Runnable {
    private static final int PACKET_LENGTH = 100;
    
    private JPanel mainPanel;
    private JPanel formPanel;
    private JTextField hostField;
    private JButton subscribe;
    private JButton unsubscribe;
    private JTextArea displayArea;
    private JButton clear;  
    private boolean isSubscribed;
    private ExecutorService runGame;
    private DatagramSocket socket;
    private String host;
    
    public Client(){
        super("Client");
        
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        add(mainPanel);
        
        formPanel = new JPanel();
        mainPanel.add(formPanel, BorderLayout.NORTH);
        
        hostField = new JTextField("localhost", 13);
        formPanel.add(hostField);
        
        subscribe = new JButton("Subscribe");
        subscribe.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    subscribeClient();                                        
                }
            }
        );
        formPanel.add(subscribe);
        
        unsubscribe = new JButton("Unsubscribe");
        unsubscribe.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    unSubscribeClient();                                        
                }
            }
        );
        formPanel.add(unsubscribe);
        
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        mainPanel.add(new JScrollPane(displayArea), BorderLayout.CENTER);
        
        clear = new JButton("Clear");
        mainPanel.add(clear, BorderLayout.SOUTH);
        clear.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    displayArea.setText("");
                }
            }
        );        
        
        isSubscribed = false;
        
        setSize(400, 300);
        setVisible(true);
        
        
        
    }
    
    
    
    private void subscribeClient() {
        host = hostField.getText();
        try {
            socket = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
            System.exit(1);
        }
        isSubscribed = true;
        sendServer("add");
        
        runGame = Executors.newFixedThreadPool(1);
        runGame.execute(this);
        
    }
    
    private void unSubscribeClient() {
        isSubscribed = false;
        sendServer("remove");
    }
    
    private void sendServer(String message) {
        try {
            byte[] data = message.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(data, data.length, 
                InetAddress.getByName(host), 6666);
            socket.send(sendPacket);
        } catch (IOException ex) {
            ex.printStackTrace();
            System.exit(1);
        } 
    }
    
    private void displayMessage(final String message) {
        SwingUtilities.invokeLater(
            new Runnable() {
                @Override
                public void run() {
                    displayArea.append(message);
                }
            }
        );
    }

    @Override
    public void run() {
        while(isSubscribed) {
            try {
                byte[] data = new byte[PACKET_LENGTH];
                DatagramPacket recievePacket = new DatagramPacket(data, 
                        data.length, InetAddress.getByName(host), 6666);
                socket.receive(recievePacket);
                LocalDateTime time = LocalDateTime.now();
                String display = String.format("%s%n%d-%s-%d %02d:%02d:%02d%n", 
                        new String(recievePacket.getData(), 0, 
                            recievePacket.getLength()),
                        time.getDayOfMonth(), time.getMonth(), time.getYear(),
                        time.getHour(), time.getMinute(), time.getSecond());
                displayMessage(display);
            } catch (IOException ex) {
                ex.printStackTrace();
                System.exit(1);
            }
        }
    }
}
