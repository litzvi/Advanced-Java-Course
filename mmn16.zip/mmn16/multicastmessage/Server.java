
import java.awt.BorderLayout;
import java.awt.event.*;
import java.io.IOException;
import java.net.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.*;

/*
 * 
 */

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class Server extends JFrame implements Runnable{
    
    public static final int PACKET_LENGTH = 100;
    
    private JTextArea textField;
    private JButton sendButton;
    private JPanel mainPanel;
    private DatagramSocket socket;
    private HashSet<InetSocketAddress> listeners;
    
    public Server() {
        super("Server");
        listeners = new HashSet<>();
        
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        add(mainPanel);
        textField = new JTextArea();
        textField.setEditable(true);
        mainPanel.add(textField, BorderLayout.CENTER);
        
        sendButton = new JButton("Send");
        sendButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent event) {
                    sendMessage(textField.getText());
                    textField.setText("");
                }
            }
        );
        mainPanel.add(sendButton, BorderLayout.SOUTH);       
        
        setSize(400, 300);
        setVisible(true);
        
        
    }
    
    public void startSrever() {
        try {
            socket = new DatagramSocket(6666);
        } catch (SocketException e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        ExecutorService worker = Executors.newFixedThreadPool(1);
        worker.execute(this);
    }
    
    @Override
    public void run() {
        while(true) {
            byte[] data = new byte[PACKET_LENGTH];
            DatagramPacket receivePacket = 
                    new DatagramPacket(data, data.length);
            
            try {
                socket.receive(receivePacket);
                InetSocketAddress address = 
                        new InetSocketAddress(receivePacket.getAddress(),
                            receivePacket.getPort());
                
                String message = new String(receivePacket.getData(), 
                    0, receivePacket.getLength());
                
                if(message.equalsIgnoreCase("add")) {
                    listeners.add(address);
                }
                else if(message.equalsIgnoreCase("remove")) {
                    listeners.remove(address);
                }
                
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            
            
        }
    }
    
    private void sendMessage(String message) {
        byte[] data = message.getBytes();
        DatagramPacket sendPacket;
        for(InetSocketAddress address: listeners) {
            sendPacket = new DatagramPacket(data, data.length, address);
            try {
                socket.send(sendPacket);
            } catch (IOException ex) {
                System.out.println("Couldn't send message to " + 
                        address.getHostName());
            }
            
        }
    }
    
    
}
