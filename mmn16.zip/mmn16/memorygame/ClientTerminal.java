/*
 * 
 */

import javax.swing.JFrame;

/**
 *
 * @author Tzvi Lieberman i.d 052821972
 */
public class ClientTerminal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MemoryGameClient app;
        
        if(args.length == 0) {
            app = new MemoryGameClient(7777);
        }
        else if(args.length == 1) {
            app = new MemoryGameClient(Integer.valueOf(args[0]));
        }
        else {
            app = new MemoryGameClient(args[0], Integer.valueOf(args[1]));
        }
        
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
