/*
 * Represents and constructs a board for memory game.
 * Randomly shuffles the cards
 */

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author Tzvi Lieberman i.d 052821972
 */
public class MemoryGameBoard implements Serializable  {

    private static final Random RAND = new Random();
    
    private final int dimension;
    private final int size;
    private ArrayList<Integer> board;
    private boolean[] open;
    private int opened;
    
    /*
    * Constroctur recives the size of the table.
    * throws an exception if not even.
    */
    public MemoryGameBoard(int dimension) throws IllegalArgumentException {
        if(dimension % 2 != 0 || dimension <= 0) {
            throw new 
                IllegalArgumentException("Board has positive even dimension");
        }
        
        this.dimension = dimension;
        size = dimension * dimension;
        opened = 0;
        board = new ArrayList(size);
        for(int i=0; i < size / 2; i++) {
            board.add(i);
            board.add(i);
        }
        Collections.shuffle(board, RAND);
        open = new boolean[size];
        Arrays.fill(open, false);
    }
    
    /*
    * returns the value of the card.
    */
    public int get(int i) {
        return board.get(i);
    }
    
    /*
    * returns true if it can currently be seen by the players.
    */
    public boolean isOpen(int i) {
        return open[i];
    }
    
    /*
    * Returns the dimension which is the root of size
    */
    public int getDimension() {
        return dimension;
    }
    
    /*
    * the amount of cards in the game.
    */
    public int size() {
        return size;
    }
    
    /*
    * Flip the card open
    */
    public void open(int i) {
        if(isOpen(i))
            throw new IllegalArgumentException("Card already opened");
        open[i] = true;
        opened++;
    }
    
    /*
    * Flip back and close the card.
    */
    public void close(int i) {
        open[i] = false;
        opened--;
    }
    
    /*
    * returns an array with the card values.
    * the still closed cards are -1
    */    
    public int[] getBoardArray() {
        int[] toReturn = new int[size];
        for(int i=0; i < size; i++) {
            toReturn[i] = open[i] ? board.get(i): -1;
        }
        return toReturn;
    }
    
    /*
    * Returns true if all cards are already open
    */
    public boolean isFull() {
        return opened == size;
    }
}
