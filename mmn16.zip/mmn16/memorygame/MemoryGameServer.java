/*
 * Server for getting pairs of players for memory game
 */

import java.io.IOException;
import java.net.*;
import java.util.concurrent.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Tzvi Lieberman i.d 052821972
 */
public class MemoryGameServer {
    
    private ServerSocket server;
    private ExecutorService runGame;
    
    public MemoryGameServer() {
        runGame = Executors.newCachedThreadPool();
    }
    
    public void execute() {
        String input;
        String message = "Enter board's dimension";
        int dimension = 0;
        
        while(dimension == 0) {
            input = JOptionPane.showInputDialog(message);        
            try {
                dimension = Integer.parseInt(input);
            } catch(NumberFormatException e) {
                message = "Wrong input: Please enter an even positive number";
            }
        }
            
        try {
            
            server = new ServerSocket(7777);
            
        } catch (IOException ex) {
            System.out.println("Exception while constructing server.");
            System.exit(1);
        }
        
        Socket socket1, socket2;
        while(true) {
            try {
                socket1 = server.accept();
                socket2 = server.accept();
                runGame.execute(new MemoryGame(dimension, socket1, socket2));
            } catch (IOException ex) {
                System.out.println("Exception while accepting players.");                
            }            
            
        }
    }
}
