/*
 * Client for participating in memory game.
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import javax.swing.*;

/**
 *
 * @author Tzvi Lieberman i.d 052821972
 */
public class MemoryGameClient extends JFrame implements Runnable {
    
    private static final int CARD_SIZE = 100;
    
    private String host;
    private int port;
    private Socket connection;
    private ObjectInputStream input;
    private ObjectOutputStream output;
    private Card[] cards;
    private MemoryGameBoard board;
    private JPanel boardPanel = null;
    private Card choose1;
    private Card choose2;
    private Lock gameLock;
    private Condition waitChoose;
    private boolean myTurn;
    
    
    public MemoryGameClient(String host, int port) { 
        super();
        this.host = host;
        this.port = port;
        choose1 = choose2 = null;
        gameLock = new ReentrantLock();
        waitChoose = gameLock.newCondition();
        myTurn = false;
        startClient();
    }
    
    public MemoryGameClient(int port) {
        this("localhost", port);
    }
    
    private void startClient() {        
        try {
            connection = new Socket(host, port);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.flush();
            input = new ObjectInputStream(connection.getInputStream());
        } catch (IOException ex) {
            System.out.println("Exception while establishing connection.");
            System.exit(1);
        }
        try {
            //recives the board and sets up the game
            board = (MemoryGameBoard)input.readObject();
        } catch (IOException ex) {
            System.out.println("Exception recieving game board.");
            System.exit(1);
        } catch (ClassNotFoundException ex) {
            System.out.println("Not synchronised with server's protocol.");
            System.exit(1);
        }
        int dimension = board.getDimension();
        int size = board.size(); 
        cards = new Card[size];
        if(boardPanel != null)
            remove(boardPanel);
        boardPanel = new JPanel();
        boardPanel.setLayout(new GridLayout(dimension, dimension, 0, 0));
        for(int i=0; i < size; i++) {
            cards[i] = new Card(board.get(i), i);
            boardPanel.add(cards[i]);
        }
        add(boardPanel);
        
        setSize(dimension * CARD_SIZE, dimension * CARD_SIZE);
        setVisible(true);
        
        ExecutorService worker = Executors.newFixedThreadPool(1);
        worker.execute(this);
        
    }
    
    @Override
    public void run() {
        try {            
            
            String message;
            boolean didUpdate = true;
            do {
                message = (String)input.readObject();//who's turn?
                if(message.equals("Your turn")) {
                    myTurn = true;
                    
                    try {
                        gameLock.lock();
                        while(myTurn) {
                            waitChoose.await();
                        }
                    } catch (InterruptedException ex) {
                        System.out.println("Exception waiting for choice.");
                    } finally {
                        gameLock.unlock();
                    }
                    
                    output.writeObject(choose1.getCardLocation() + 
                            " " + choose2.getCardLocation());
                }
                else if(message.equals("Other's turn")) {
                    message = (String)input.readObject();
                    String[] chosen = message.split(" ");
                    choose1 = cards[Integer.valueOf(chosen[0])];
                    choose2 = cards[Integer.valueOf(chosen[1])];
                    choose1.openCard();
                    choose2.openCard();
                    
                    
                }
                else {
                    didUpdate = false;
                }
                
                if(didUpdate) {
                    if(choose1.getCardIndex() 
                            != choose2.getCardIndex()) {
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException ex) {
                            System.out.println("Exception while sleeping.");
                        }
                        choose1.closeCard();
                        choose2.closeCard();


                    }
                    else {
                        board.open(choose1.getCardLocation());
                        board.open(choose2.getCardLocation());
                    }
                }
                choose1 = choose2 = null;
                
            } while(!message.equals("Game Finished"));
                        
            message = (String)input.readObject();//game result
            JOptionPane.showMessageDialog(this, message);
            
            
        } catch (IOException ex) {
            //Maybe it's just end of stream
            ex.printStackTrace();
            System.exit(1);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            System.exit(1);
        } finally {
            closeResources();
        }
        
        int answer = JOptionPane.showConfirmDialog(this, 
                        "Would you like to play another game?", 
                                "Replay", JOptionPane.YES_NO_OPTION);
            
        if(answer == JOptionPane.YES_OPTION) {
            startClient();
        }
        
    }
    
    //closes resources
    public void closeResources() {
        try {
            input.close();
            output.close();
            connection.close();
        } catch (IOException ex) {
            ex.printStackTrace();
            System.exit(1);
        }
    }
    
        
    /*
    * opens a card if it's player's turn and didn't open 2 closed ones
    */
    private void openCurrentCard(Card card) {
        if(!myTurn || board.isOpen(card.getCardLocation()) || card == choose1)
            return;        
            
        card.openCard();       
        if(choose1 == null) {
            choose1 = card;
        }
        else if(choose2 == null) {
            choose2 = card;
            myTurn = false;
            
            gameLock.lock();
            waitChoose.signal();
            gameLock.unlock();
        }
    }
    
    
    /*
    * calss to representd the card/image
    */
    private class Card extends JButton {
        private int location;
        private int index;
        private String img;

        public Card(int index, int location) {
            this.index = index;
            this.location = location;
            img = " ";

            addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        openCurrentCard(Card.this);                                        
                    }
                }
            );
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(CARD_SIZE, CARD_SIZE);
        }

        @Override
        public Dimension getMinimumSize() {
            return getPreferredSize();
        }

        public void openCard() {
            img = String.format("%d", index);
            //repaint();
            SwingUtilities.invokeLater(
                    new Runnable() {
                        @Override
                        public void run() {
                            setText(img);
                        }
                    }
            );
            
            
        }

        public void closeCard() {
            img = " ";
            //repaint();
            SwingUtilities.invokeLater(
                    new Runnable() {
                        @Override
                        public void run() {
                            setText(img);
                        }
                    }
            );
            
        }

        public int getCardLocation() {
            return location;
        }
        
        public int getCardIndex() {
            return index;
        }
        
    }
}
