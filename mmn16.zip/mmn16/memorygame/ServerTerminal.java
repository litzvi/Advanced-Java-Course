/*
 * 
 */

/**
 *
 * @author Tzvi Lieberman i.d 052821972
 */
public class ServerTerminal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MemoryGameServer server = new MemoryGameServer();
        server.execute();
    }
    
}
