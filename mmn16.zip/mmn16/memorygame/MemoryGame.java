/*
 * Runs the server side of a single memory game
 */

import java.io.*;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Tzvi Lieberman i.d 052821972
 */
public class MemoryGame implements Runnable {
       
    private final MemoryGameBoard board;
    private final Player player1, player2;
    
    /*
    * Constroctur
    * Recives the size for the game and 2 sockets for connectng to the players.
    */
    public MemoryGame(int dimension, Socket socket1, Socket socket2) {
        board = new MemoryGameBoard(dimension);
        player1 = new Player(socket1);
        player2 = new Player(socket2);
        
    }

    @Override
    public void run() {
        try {
            //sends board to both players
            player1.sendObject(board);
            player2.sendObject(board);

            Player playing = player1, waiting = player2, temp; 
            while(!board.isFull()) {          
                //informs every player if it's his turn
                playing.sendObject("Your turn");
                waiting.sendObject("Other's turn");            

                String message = playing.reciveMessage();//recives move
                String[] chosen = message.split(" ");
                int first = Integer.valueOf(chosen[0]);
                int second = Integer.valueOf(chosen[1]);            

                waiting.sendObject(message);//sends move to the other player

                //if the cards opened are matching
                if(board.get(first) == board.get(second) && first != second) {
                    board.open(first);
                    board.open(second);
                    playing.addPoint();
                }

                temp = playing;
                playing = waiting;
                waiting = temp;


            }
            //notify end of game
            player1.sendObject("Game Finished");
            player2.sendObject("Game Finished");

            Player winner, looser;
            String winMessage = "You Won\n";
            String loseMessage = "You Losed\n";
            if(player1.getPoints() == player2.getPoints()) {
                winMessage = loseMessage = "Draw\n";
            }

            if(player1.getPoints() >= player2.getPoints()) {
                winner = player1;
                looser = player2;
            }
            else {
                winner = player2;
                looser = player1;
            }
            //send result
            String result = String.format("First player: %d%nSecondPlayer: %d%n", 
                    player1.getPoints(), player2.getPoints());

            winner.sendObject(winMessage + result);
            looser.sendObject(loseMessage + result);
        } catch (IOException | ClassNotFoundException ex ) {
            System.out.println("Comunication exception.");
        }  finally {
            closeAllResources();
        }
        
    }
        
        
        
    public void closeAllResources() {
        player1.closeResources();       
        player2.closeResources();
    }

    
    
    private class Player {

        private Socket connection;
        private ObjectInputStream in;
        private ObjectOutputStream out;
        private int points;
        
        //Constroctur
        public Player(Socket socket) {
            connection = socket;
            points = 0;
            
            try {
                out = new ObjectOutputStream(connection.getOutputStream());
                out.flush();
                in = new ObjectInputStream(connection.getInputStream());
            } catch (IOException ex) {
                System.out.println("Exception while constructing streams.");
                System.exit(1);
            } 
        }
        
        public void addPoint() {
            points++;
        }
        
        public int getPoints() {
            return points;
        }
        
        public void sendObject(Object obj) throws IOException {
            out.writeObject(obj);
            out.flush();

        }
        
                
        public String reciveMessage() throws IOException, ClassNotFoundException {
            String message = (String)in.readObject();
            return message;
        }
        
        public void closeResources() {
            try {
                in.close();
                out.close();
                connection.close();
            } catch (IOException ex) {
                System.out.println("Exception while closing resources.");
                System.exit(1);
            }

        }
    }
    
}
