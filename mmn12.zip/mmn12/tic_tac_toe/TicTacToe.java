/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class TicTacToe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GameLogic gameLogic = new GameLogic();
        gameLogic.start();
        GamePanel panel = new GamePanel(gameLogic);
        JFrame app = new JFrame();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.add(panel);
        app.setSize(300, 300);
        app.setVisible(true);
        
        String inputMessage = "Please input raw and colomn numbers (0-2) ";
        if(gameLogic.isPlayerX())
            inputMessage += "For X\n";
        else
            inputMessage += "For O\n";
        String exceptionMessage = "";
        String input;
        char[] index;
        boolean isPlaying = !gameLogic.isFinished();
        while(isPlaying) { 
            
            try {
                input = JOptionPane.showInputDialog(exceptionMessage + inputMessage);
                exceptionMessage = "";
                index = input.toCharArray();
                gameLogic.makeMove(Integer.parseInt(String.valueOf(index[0])),
                        Integer.parseInt(String.valueOf(index[1])));
                app.repaint();
            }
            catch(ChosenCellException e) {
                exceptionMessage = e.getMessage() + '\n';
            }
            catch(Exception e) {
                exceptionMessage = "Wrong input: Enter 2 numbers between 0-2\n";
            }
            
            // game is over, ask if want to play again.
            if(gameLogic.isFinished()) {
                String display = "Game is over!\n";
                String whoWon;
                if(gameLogic.isPlayerWin())
                    whoWon = "You ";
                else
                    whoWon = "Computer ";
                switch(gameLogic.getWinner()) {
                    case O:
                        display += whoWon + "(O) won!\n";
                        break;
                    case X:
                        display += whoWon + "X won!\n";
                        break;
                    case DRAW:
                        display += "It was a draw!\n";
                        break;
                }
                display += "Do you want to play another game?\n";
                int answer = JOptionPane.showConfirmDialog(null, display);
                if(answer != JOptionPane.OK_OPTION) {
                    isPlaying= false;                    
                }
                else {
                    gameLogic.start();
                    app.repaint();
                    inputMessage = "Please input raw and colomn numbers (0-2) ";
                    if(gameLogic.isPlayerX())
                        inputMessage += "For X\n";
                    else
                        inputMessage += "For O\n";
                }
            }            
        }
        app.dispose();
        
    }
    
}
