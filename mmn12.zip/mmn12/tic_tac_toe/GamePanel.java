/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JPanel;
import java.awt.Graphics;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class GamePanel extends JPanel {
    
    private GameLogic gameLogic;
    
    // Constructor for the board panel gets the game logic.
    public GamePanel(GameLogic gameLogic) {
        this.gameLogic = gameLogic;
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        int width = getWidth();
        int height = getHeight();
        int cellWidth = width / GameLogic.DIMENSION;
        int cellHeight = height / GameLogic.DIMENSION;
        
        g.drawLine(0, cellHeight, width, cellHeight); // draws horizental line
        g.drawLine(0, 2 * cellHeight, width, 2 * cellHeight); // second horizental
        g.drawLine(cellWidth, 0, cellWidth, height); // draws vertical line
        g.drawLine(2 * cellWidth, 0, 2 * cellWidth, height); // second vertical line
        
        //fills the cells with X or O.
        for(int i = 0, j; i < GameLogic.DIMENSION; i++){
            for(j = 0; j < GameLogic.DIMENSION; j++) {
                if(gameLogic.getCell(i, j) == 0) {
                    g.drawOval(j * cellWidth, i * cellHeight, 
                            cellWidth, cellHeight);                    
                }
                else if(gameLogic.getCell(i, j) == 1){
                    g.drawLine(j * cellWidth, i * cellHeight, 
                            (j+1) * cellWidth, (i+1) * cellHeight);
                    g.drawLine((j+1) * cellWidth, i * cellHeight, 
                            j * cellWidth, (i+1) * cellHeight);
                }
            }
        }
    }
}
