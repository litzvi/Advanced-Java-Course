/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class ChosenCellException extends IllegalArgumentException {

    /**
     * Creates a new instance of <code>ChosenCellException</code> without detail
     * message.
     */
    public ChosenCellException() {
    }

    /**
     * Constructs an instance of <code>ChosenCellException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public ChosenCellException(String msg) {
        super(msg);
    }
}
