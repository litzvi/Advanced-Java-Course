/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Random;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class GameLogic {
    public static final int DIMENSION = 3; // board dimensions
    private static final Random randGen = new Random();// for picking the first player.
    
    // logic representation of the board. -1 for empty, 0 for O and 1 for X.
    private int[][] board = new int[DIMENSION][DIMENSION]; 
    private Winner winner; 
    private boolean machineStarts; // true if machine is X and starts.
    private int totalMoves;
    
    /* 
    * Sets the game initial values and resets the game.
    * Has to be used in order to set up the game.
    */
    public void start() {
        for(int i = 0; i < DIMENSION; i++){
            for(int j = 0; j < DIMENSION; j++){
                board[i][j] = -1;
            }
        }
        winner = Winner.PLAYING;
        totalMoves = 0;
        machineStarts = randGen.nextBoolean();
        if(machineStarts) {
            machineMove();
        }
    }
    
    /*
    * returns the -1 if the cell on the board is yet to be filled,
    * 0 for O and 1 if filled by X.
    */
    public int getCell(int i, int j) {
        return board[i][j];
    }
    
    /*
    * Makes the next machine move according to the logic that he will chooe the
    * line which will fill a line to win if he can. Otherwise, 
    * fill a second cell in a line he can still win on else a line he can still
    * win.
    * Assumes the game is not finished yet.
    */
    private void machineMove() throws IllegalArgumentException {
       int line = -1, raw = -1, maxHeuristic = -1, heuristic;
       int machine = machineStarts ? 1: 0;
       // Choose the best cell by our heuristic.
       for(int i = 0, j; i < DIMENSION; i++) {
           for(j = 0; j < DIMENSION; j++){
               // checks th heuristic value if available
               if(getCell(i, j) == -1) { 
                   heuristic = getHeuristic(i, j, machine);
                   if(heuristic > maxHeuristic) {
                        maxHeuristic = heuristic;
                        line = i;
                        raw = j;
                   }
               }
                   
           }
       }   
       
       // No available cell.
       if(line == -1) {
           throw new IllegalArgumentException("No empty cell");
       }
       
       makeMove(line, raw, machine);
    }
    
    /*
    * Checks the Huristic to get the value for a given move.
   */
    private int getHeuristic(int i, int j, int player) 
            throws IllegalArgumentException {
        if(getCell(i, j) != -1)
            throw new IllegalArgumentException("Chosen cell already filled");
        
        //check raw state.
        
        int rawRank = getMoveRank((i + 1) % DIMENSION, j, 
                (i + 2) % DIMENSION, j, player);
        int colomnRank = getMoveRank(i, (j + 1) % DIMENSION, 
                i, (j + 2) % DIMENSION, player);
        int rank = rawRank > colomnRank ? rawRank : colomnRank;
        int fSlashRank = 0, bSlashRank = 0;
        if(i == j) {
            int index1 = (i + 1) % DIMENSION;
            int index2 = (i + 2) % DIMENSION;
            bSlashRank = getMoveRank(index1, index1, index2, index2, player);
            if(bSlashRank > rank)
                rank = bSlashRank;
        }
        if(i == (DIMENSION - 1 -j)) {
            fSlashRank = getMoveRank((i + 1) % DIMENSION , (j + 2) % DIMENSION,
                    (i + 2) % DIMENSION ,(j + 1) % DIMENSION , player);
            if(fSlashRank > rank)
                rank = fSlashRank;
        }
        
        //gives a slightly higher ranking for cells that have more line options.
        int openLines = 0;
        if(rawRank > 0)
            openLines++;
        if(colomnRank > 0)
            openLines++;
        if(fSlashRank > 0)
            openLines++;
        if(bSlashRank > 0)
            openLines++;
        if(openLines > rank)
            rank = openLines;
        
        return rank;        
    }
    
    /*
    * Ranks the value for given line.
    * Heighst is completing a line (6), second blocking another line (5),
    * then comes a line that can be won (1) and last a line which can't be won(0).
    * returns 6 and 5 for the high order so the calling function can add up
    * open lines but still not get higher priority than completing or blocking 
    * a line.
    * recives the 2 other cells and the player.
    */
    private int getMoveRank(int i1, int j1, int i2, int j2, int player) {
        int oponent = 1 - player;
        int cell1 = getCell(i1, j1);
        int cell2 = getCell(i2, j2);
        if(cell1 == cell2) {
            if(cell1 == player) {
                return 6;
            }
            else if(cell1 == oponent){
                return 5;
            }            
        }
        if((cell1 != oponent) && (cell2 != oponent)) {
            return 1;
        }
        return 0;
    } 
    
    /*
    * returns -1 if no winner yet, 0 if O won, 1 if X won and 2 for draw.
    */
    public Winner getWinner() {
        return winner;
    }
    
    public boolean isPlayerX() {
        return !machineStarts;
    }
    
    public boolean isPlayerWin() {
        if((!machineStarts && winner == Winner.X) || 
                (machineStarts && winner == Winner.O)) {
            return true;    
        }
        return false;
    }
    
    /*
    * returns true if the game is finished.
    */
    public  boolean isFinished() {
        return winner != Winner.PLAYING;
    }
    
    /*
    * For the player to choose a cell for  this turn.
    */
    public void makeMove(int i, int j)
            throws IllegalArgumentException {
        int player = machineStarts ? 0: 1;
        makeMove(i, j, player);
        if(!isFinished()) {
            machineMove();
        }
    }
    
    /*
    * Logic for making a move for the machine or player.
    * plyer is 0 for O and 1 for X.
    */
    private void makeMove(int i, int j, int player) 
            throws IllegalArgumentException {
        if(getCell(i, j) != -1)
            throw new ChosenCellException("Chosen cell already filled");
        if(isFinished())
            throw new IllegalArgumentException("Game already over");
            
        board[i][j] = player;
        totalMoves++;
        
        //check won on raw or colomn.
        boolean winLine = true, winColomn = true;
        for(int k = 0; k < DIMENSION; k++){
            if(board[i][k] != player)
                winLine = false; 
            if(board[k][j] != player)
                winColomn = false;
        }
        // Check if won on slash.
        boolean winForward = false, winBack = false;
        if(!winLine && !winColomn && (i == j || i == DIMENSION - 1 - j)) {
            winForward = winBack = true;
            for(int k = 0; k < DIMENSION; k++){
                if(board[k][k] != player)
                    winBack = false; 
                if(board[k][DIMENSION - 1 - k] != player)
                    winForward = false;
                }
        }
        
        if(winLine || winColomn || winForward || winBack) {
            if(player == 0)
                winner = Winner.O;
            else
                winner = Winner.X;
        }        
        else if(totalMoves == DIMENSION * DIMENSION) {
            winner = Winner.DRAW;
        }
    }
    
    public String toString() {
        String toReturn = "";
        for(int i =0, j; i < DIMENSION; i++) {
            for(j = 0; j < DIMENSION; j++) {
                toReturn += getCell(i, j) + " ";
            }
            toReturn += '\n';
        }
        
        return toReturn;
    }
    
}
