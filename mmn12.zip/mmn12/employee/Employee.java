// Fig. 10.4: Employee.java
// Employee abstract superclass.

import java.util.ArrayList;

public abstract class Employee 
{
   private final String firstName;
   private final String lastName;
   private final String socialSecurityNumber;
   private ArrayList<String> children;

   // constructor
   public Employee(String firstName, String lastName, 
      String socialSecurityNumber, String... children)
   {
      this.firstName = firstName;                                    
      this.lastName = lastName;                                    
      this.socialSecurityNumber = socialSecurityNumber; 
      this.children = new ArrayList<String>();
      for(String child: children)
      {
        this.children.add(child);
      }
   } 
   
   // return first name
   public String getFirstName()
   {
      return firstName;
   } 

   // return last name
   public String getLastName()
   {
      return lastName;
   } 

   // return social security number
   public String getSocialSecurityNumber()
   {
      return socialSecurityNumber;
   } 
   
   // add a child ID 
   public void addChild(String childID)
   {
       children.add(childID);
   }
   
   // return a string of children's ID
   public String[] getChildren()
   {
       String[] childrenArray = new String[children.size()];
       return children.toArray(childrenArray);
   }

   // return String representation of Employee object
   @Override
   public String toString()
   {
      String toReturn = 
              String.format("%s %s%nsocial security number: %s%nchildren:", 
                      getFirstName(), getLastName(), getSocialSecurityNumber());
      for(String child: getChildren())
          toReturn += "\n" + child;
      return toReturn;
   } 
   
   @Override
   public boolean equals(Object anObject)
   {
       if(!(anObject instanceof Employee)){
           return false;
       }
       Employee employee = (Employee)anObject;
       return employee.getSocialSecurityNumber().
               equals(this.getSocialSecurityNumber());
       
   }
      
   
   @Override
   public abstract Object clone();

   // abstract method must be overridden by concrete subclasses
   public abstract double earnings(); // no implementation here
} // end abstract class Employee


/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
