// Fig. 10.9: PayrollSystemTest.java
// Employee hierarchy test program.
import java.util.ArrayList;

public class PayrollSystemTest 
{
   public static void main(String[] args) 
   {
      String[] children = {"123456", "3258", "8547"};
      // create subclass objects
      SalariedEmployee salariedEmployee = 
         new SalariedEmployee("John", "Smith", "111-11-1111", 800.00, children);
      HourlyEmployee hourlyEmployee = 
         new HourlyEmployee("Karen", "Price", "222-22-2222", 16.75, 40);
      CommissionEmployee commissionEmployee = 
         new CommissionEmployee(
         "Sue", "Jones", "333-33-3333", 10000, .06);
      BasePlusCommissionEmployee basePlusCommissionEmployee = 
         new BasePlusCommissionEmployee(
         "Bob", "Lewis", "444-44-4444", 5000, .04, 300, "4444");

      
      // create Employee array
      ArrayList<Employee> employees = new ArrayList<>(); 

      // initialize array with Employees
      employees.add(salariedEmployee);
      employees.add(hourlyEmployee);
      employees.add(commissionEmployee); 
      employees.add(basePlusCommissionEmployee);

      System.out.printf("Employees processed polymorphically:%n%n");
      
      // generically process each element in array employees
      for (Employee currentEmployee : employees) 
      {
         System.out.println(currentEmployee); // invokes toString         
      } 
      
      // checking if equals tests the id only
      salariedEmployee = new SalariedEmployee("An", "Vu", "235689", 800.00);
      basePlusCommissionEmployee = new BasePlusCommissionEmployee(
         "Zvi", "Lieberman", "235689", 5000, .04, 300, "4444");
      System.out.println("Testing 'equals' function:");
      System.out.printf("Does An equal Zvi?: %b%n", 
              salariedEmployee.equals(basePlusCommissionEmployee));
      
      // cloning and checking if it's a diffrent object with adeep copy
      Object copy = basePlusCommissionEmployee.clone();
      System.out.printf("Printing the copy:%n%s%n", copy);
      basePlusCommissionEmployee.addChild("05282");
      System.out.printf("Printing the original:%n%s%n", basePlusCommissionEmployee);
      System.out.printf("Printing the copy:%n%s%n", copy);

   } // end main
} // end class PayrollSystemTest

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
