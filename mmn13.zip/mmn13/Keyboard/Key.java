/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyboard;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public enum Key {
    TILDE("`/~", "`", "~"),
    ONE("1/!", "1", "!"),
    TWO("2/@", "2", "@"),
    THREE("3/#", "3", "#"),
    FOUR("4/$", "4", "$"),
    FIVE("5/%", "5", "%"),
    SIX("6/^", "6", "^"),
    SEVEN("7/&", "7", "&"),
    EIGHT("8/*", "8", "*"),
    NINE("9/(", "9", "("),
    TEN("0/)", "0", ")"),
    UNDERSCORE("-/_", "-", "_"),
    EQUAL("=/+", "=", "+"),
    BACKSPACE("Backspace", null, null),
    TAB("Tab", "    ", "    "),
    Q("Q", "q", "Q"),
    W("W", "w", "W"),
    E("E", "e", "E"),
    R("R", "r", "R"),
    T("T", "t", "T"),
    Y("Y", "y", "Y"),
    U("U", "u", "U"),
    I("I", "i", "I"),
    O("O", "o", "O"),
    P("P", "p", "P"),
    OPEN_BRACE("[/{", "[", "{"),
    CLOSE_BRACE("]/}", "]", "}"),
    PIPE("\\/|", "\\", "|"),
    CAPS("Caps", null, null),
    A("A", "a", "A"),
    S("S", "s", "S"),
    D("D", "d", "D"),
    F("F", "f", "F"),
    G("G", "g", "G"),
    H("H", "h", "H"),
    J("J", "j", "J"),
    K("K", "k", "K"),
    L("L", "l", "L"),
    COLON(";/:", ";", ":"),
    QUOTE("'/\"", "'", "\""),
    ENTER("Enter", "\n", "\n"),
    LEFT_SHIFT("Shift", null, null),
    Z("Z", "z", "Z"),
    X("X", "x", "X"),
    C("C", "c", "C"),
    V("V", "v", "V"),
    B("B", "b", "B"),
    N("N", "n", "N"),
    M("M", "m", "M"),
    LESS_THAN(",/<", ",", "<"),
    GREATER_THAN("./>", ".", ">"),
    QUESTION("//?", "/", "?"),
    RIGHT_SHIFT("Shift", "", ""),
    SPACE("                                                        ", " ", " ");
    
    private final String name;
    private final String value;
    private final String shiftValue;

    //enum constroctur
    Key(String name, String value, String shiftValue){
        this.name = name;
        this.value = value;
        this.shiftValue = shiftValue;
    }
    
    // lower case value
    public String getName() {
        return name;
    }
    
    // lower case value
    public String getValue() {
        return value;
    }
    
    // upper case value
    public String getShiftValue() {
        return shiftValue;
    }
}
