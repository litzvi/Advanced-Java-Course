/*
 * represents a note on a keyboard.
*/
package keyboard;

import javax.swing.JButton;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class KeyButton extends JButton{
    private Key key;
    
    /*
    * Constroctur recives name of the Key, lower case value and upper case.
    */
    public KeyButton(Key key){
        super(key.getName());
        this.key = key;
    }
    
    public Key getKey() {
        return key;
    }
        
    
}
