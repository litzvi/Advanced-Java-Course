/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyboard;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class BoardPanel extends JPanel{
    // amount of keys that fit in one line
    private static final int NO_KEY_FIT = 14; 
    private static final int KEY_ROWES = 5;
    private static final int ROW1 = 0;
    private static final int ROW2 = 14;
    private static final int ROW3 = 28;
    private static final int ROW4 = 41;
    private static final int ROW5 = 53;
    
    private final JTextArea monitor;
    private boolean isShiftPressed = false;
    Color background;
    
    public BoardPanel() {
        super();
        background = getBackground();
        // sets up the text area and keyboard
        JPanel boardPanel = new JPanel(new GridLayout(2,1));
        add(boardPanel);
        // text area
        monitor = new JTextArea("");
        monitor.setEnabled(false);
        monitor.setDisabledTextColor(Color.BLACK);
        monitor.setFont(new Font("Serif", Font.PLAIN, 18));
        boardPanel.add(monitor);
        
        //keyboard
        JPanel keyPanel = new JPanel(new GridLayout(KEY_ROWES,1));
        boardPanel.add(keyPanel);
        
                
        JPanel[] keyRows = new JPanel[KEY_ROWES];
        for(int i = 0; i < KEY_ROWES; i++) {
            keyRows[i] = new JPanel();
            keyPanel.add(keyRows[i]);
        }
        
        // create all keys and add listeners
        KeyButton[] buttonKeys = new KeyButton[Key.values().length];
        int i = 0;
        for(Key key: Key.values()) {
            buttonKeys[i] = new KeyButton(key);
            
            switch(key) { // adds the needed listener
                case BACKSPACE:
                    buttonKeys[i].addActionListener(new BackspaceListener());                    
                    break;
                case RIGHT_SHIFT:
                case LEFT_SHIFT:
                case CAPS:
                    buttonKeys[i].addActionListener(new ShiftListener());
                    break;       
                default:
                    buttonKeys[i].addActionListener(new KeyListener());
                    break;
            }
            
            //Add buttons to rows
            if(i < ROW2) {
                keyRows[0].add(buttonKeys[i]);
            }
            else if(i < ROW3) {
                keyRows[1].add(buttonKeys[i]);
            }
            else if(i < ROW4) {
                keyRows[2].add(buttonKeys[i]);
            }
            else if(i < ROW5) {
                keyRows[3].add(buttonKeys[i]);
            }
            else {
                keyRows[4].add(buttonKeys[i]);
            }            
            i++;
        }        
        
    }

    private class ShiftListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            isShiftPressed = !isShiftPressed;
            if(isShiftPressed)
                ((JButton)(ae.getSource())).setBackground(Color.YELLOW);
            else
                ((JButton)(ae.getSource())).setBackground(background);
            
        }
    }

    private class BackspaceListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            String text = monitor.getText();
            monitor.setText(text.substring(0, text.length() - 1));
        }
    }

    private class KeyListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            Key key = ((KeyButton)ae.getSource()).getKey();
            if(isShiftPressed) {
                monitor.append(key.getShiftValue());
            }
            else {
                monitor.append(key.getValue());
            }
        }
    }
    
}
