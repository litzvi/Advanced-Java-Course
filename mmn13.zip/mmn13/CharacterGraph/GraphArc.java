/*
 * A graph arc connecting 2 nodes.
 */
package charactergraph;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class GraphArc implements Comparable<GraphArc> {
    
    private GraphNode node1;
    private GraphNode node2;
    
    //constroctur
    public GraphArc(GraphNode node1, GraphNode node2) {
        if(node1.compareTo(node2) <= 0) {
            this.node1 = node1;
            this.node2 = node2;
        }
        else {
            this.node1 = node2;
            this.node2 = node1;
        }
    }
    
    // returns the first nodes on the arc (lower lexicographically)
    public GraphNode getNode1(){
        return node1;
    }
    
    // returns the second nodes on the arc (higher lexicographically)
    public GraphNode getNode2(){
        return node2;
    }
    
    // returns true if the given node is on the arc.
    public boolean connects(GraphNode node) {
        return connects(node.getName());
    }
    
    // returns true if the given node name is on the arc.
    public boolean connects(char name) {
        return name == getNode1().getName() || name == getNode2().getName();
    }
    
    @Override
    public boolean equals(Object arc) {
        if(!(arc instanceof GraphArc)) {
            return false;
        }
        else if(compareTo((GraphArc)arc) == 0){
            return true;
        }
        return false;        
    }

    @Override
    public int compareTo(GraphArc arc) {
        int cmpNode1 = getNode1().compareTo(arc.getNode1());
        if(cmpNode1 != 0){
            return cmpNode1;
        }
        return getNode2().compareTo(arc.getNode2());
    }
    
    @Override
    public String toString() {
        return String.format("(%s, %s)", getNode1(), getNode2());
    }
    
}
