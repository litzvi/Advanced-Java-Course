/*
 * A graph consisting of Comparable Nodes and Arcs.
*/
package charactergraph;

import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class Graph {
    
    private TreeMap<Character, GraphNode> nodes;
    private TreeSet<GraphArc> arcs;
    
    // Constroctur
    public Graph() {
        nodes = new TreeMap<>();
        arcs = new TreeSet<>();
    }
    
    // Constrocturthat gets nodes and arcs
    public Graph(GraphNode[] nodes, GraphArc[] arcs) {
        this();
        
        //fill Nodes
        for(GraphNode node: nodes) {
            if(this.nodes.containsValue(node))
                throw new IllegalArgumentException("Node already in the Graph");
            this.nodes.put(node.getName(), node);
                
        }
        
        //fill arcs
        for(GraphArc arc: arcs) {
            GraphNode node1 = this.nodes.get(arc.getNode1().getName());
            GraphNode node2 = this.nodes.get(arc.getNode2().getName());
            if(node1 == null || node2 == null)
                throw new IllegalArgumentException("Arc node not in Graph");
                        
            else if(!this.arcs.add(arc))
                throw new IllegalArgumentException("Arc already in the Graph");
        }
    }
    
    // Clears the whole graph
    public void clear() {
        nodes.clear();
        arcs.clear();
    }
    
      // Adds a node to the graph. Throws exception if the node already exists.
    public void addNode(GraphNode node) {
        if(this.nodes.containsValue(node))
                throw new IllegalArgumentException("Node already in the Graph");
            this.nodes.put(node.getName(), node);
        
    }
    
    /*
    * Deletes a give node and all arcs connecting it. 
    * Throws exception if the node is not in the graph.
    */
    public void deleteNode(GraphNode node) {
        deleteNode(node.getName());
    
    }
    
    public void deleteNode(char name) {
        if(!nodes.containsKey(name))
            throw new IllegalArgumentException("Node not in the Graph");
        
        // Remove connecting arcs
        for(GraphArc arc: arcs){
            if(arc.connects(name))
                deleteArc(arc);
        }
        
        // remove the node
        nodes.remove(name);
        
    }
    
    /*
    * Adds an arc by getting 2 node names
    */
    public void addArc(char name1, char name2) {
        GraphNode node1 = nodes.get(name1);
        GraphNode node2 = nodes.get(name2);
        
        // Checks if the arc's nodes are in the graph
        if(node1 == null || node2 == null)
            throw new IllegalArgumentException("Arc node not in the Graph");
        
        if(!arcs.add(new GraphArc(node1, node2)))
            throw new IllegalArgumentException("Arc already in the Graph");
    }
    
    /*
    * Adds an arc to the graph. If the nodes of the arc are not in the graph 
    * or the arc already exists we throw an Exception.
    */
    public void addArc(GraphArc arc) {
        // Checks if the arc's nodes are in the graph
        if(!containsNode(arc.getNode1()) || !containsNode(arc.getNode2()))
            throw new IllegalArgumentException("Arc node not in the Graph");
        
        if(!arcs.add(arc))
            throw new IllegalArgumentException("Arc already in the Graph");
    }
  
    /*
    * Delets an Arc from the graph, the arc is given by the 2 node names.
    * Throws an Exception if the Arc dosen't exist.
    */
    public void deleteArc(char name1, char name2) {
        deleteArc(new GraphNode(name1), new GraphNode(name2));
    }
    
    /*
    * Delets an Arc from the graph.
    * Throws an Exception if the Arc dosen't exist.
    */
    public void deleteArc(GraphArc arc) {
        if(!arcs.remove(arc))
            throw new IllegalArgumentException("Arc not in the Graph");
    }
    
    /*
    * Delets the Arc connecting the 2 nodes from the graph.
    * Throws an Exception if the Arc dosen't exist.
    */
    public void deleteArc(GraphNode node1, GraphNode node2){
        deleteArc(new GraphArc(node1, node2));
    }
    
    // Returns a list of nodes.
    public GraphNode[] getNodes() {
        
        return nodes.values().toArray(new GraphNode[0]);        
    }
    
    // Returns a list of arcs.
    public GraphArc[] getArcs() {
        
        return arcs.toArray(new GraphArc[0]);        
    }
    
    // Checks if a given node is in the graph.
    public boolean containsNode(GraphNode node) {
        return nodes.containsKey(node.getName());
    }
    
    // Checks if a given arc is in the graph.
    public boolean containsArc(GraphArc arc) {
        return arcs.contains(arc);
    }
    
    @Override
    public String toString() {
        //write nodes
        boolean isFirst = true;
        String toReturn = "";
        for(GraphNode node: nodes.values()) {
            if(isFirst) {
                toReturn = String.format("List of nodes%n{%s", node);
                isFirst = false;
            }
            else {
                toReturn += ", " + node;
            }
        }
        toReturn += "}\n";
        
        //write arcs
        isFirst = true;
        for(GraphArc arc: arcs) {
            if(isFirst) {
                toReturn += String.format("List of arcs%n{%s", arc);
                isFirst = false;
            }
            else {
                toReturn += ", " + arc;
            }
        }
        toReturn += "}\n";
        return toReturn;
    }
    
    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Graph))
            return false;
        //Since we keep the lists in order the toSting's will be equal
        Graph graph = (Graph)obj;
        return toString().equals(graph.toString());
    }

}
