/*
 * Represents the Panel we draw the graph on.
*/
package charactergraph;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author User
 */
public class DrawPanel extends JPanel{
    
    private final Graph graph;
    
    public DrawPanel(Graph graph) {
        this.graph = graph;
    }
    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        g.setFont(new Font("Serif", Font.BOLD, 20));
        char[] chars = new char[1];
        for(GraphNode node: graph.getNodes()) {
            Graph2DNode drawNode = (Graph2DNode)node;
            chars[0] = drawNode.getName();
            g.drawChars(chars, 0, 1, drawNode.getX(), drawNode.getY());
        }
        
        g.setColor(Color.blue);
        for(GraphArc arc: graph.getArcs()) {
            Graph2DNode node1 = (Graph2DNode)arc.getNode1();
            Graph2DNode node2 = (Graph2DNode)arc.getNode2();
            g.drawLine(node1.getX(), node1.getY(), node2.getX(), node2.getY());
        }
    }
}
