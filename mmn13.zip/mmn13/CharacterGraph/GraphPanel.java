/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package charactergraph;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import javax.swing.JPanel;

/**
 *
 * @author User
 */
public class GraphPanel extends JPanel{
    
    
    private Graph graph;
    private final DrawPanel drawPanel;
    private final JPanel buttonPanel;
    private final JButton delNode;
    private final JButton addArc;
    private final JButton delArc;
    private final JButton clear;
    
    public GraphPanel() {
        super(new BorderLayout());
        graph = new Graph();
        drawPanel = new DrawPanel(graph);
        add(drawPanel, BorderLayout.CENTER);
        drawPanel.addMouseListener(new AddNodeHandler());
        
        buttonPanel = new JPanel();
        add(buttonPanel, BorderLayout.NORTH);
        
        delNode = new JButton("Delete Node");
        buttonPanel.add(delNode);
        delNode.addActionListener(new DelNodeHandler());
        
        addArc = new JButton("Add Arc");
        buttonPanel.add(addArc);
        addArc.addActionListener(new AddArcHandler());

        
        delArc = new JButton("Delete Arc");
        buttonPanel.add(delArc);
        delArc.addActionListener(new DelArcHandler());
        
        clear = new JButton("Clear");
        buttonPanel.add(clear);
        clear.addActionListener(new ClearHandler());
    }
    
    // Clears the graph
    private class ClearHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            graph.clear();
            repaint();
        }
    }

    // Adds arc to graph
    private class AddArcHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                char name1 = getNodeName("Enter First Node Name", "Add Arc");
                char name2 = getNodeName("Enter Second Node Name", "Add Arc");
                graph.addArc(name1, name2);
                drawPanel.repaint();
            }
            catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), 
                        "Wrong Input", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Deletes arc from graph.
    private class DelArcHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                char name1 = getNodeName("Enter First Node Name", "Add Arc");
                char name2 = getNodeName("Enter Second Node Name", "Add Arc");
                graph.deleteArc(name1, name2);
                drawPanel.repaint();
            }
            catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), 
                        "Wrong Input", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Delete Node
    private  class DelNodeHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            try {
                graph.deleteNode(new GraphNode(getNodeName("Enter Node Name", 
                        "Remove Node")));
                drawPanel.repaint();
            }
            catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), 
                        "Wrong Input", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Adds the node to the Graph
    private class AddNodeHandler extends MouseAdapter {

        @Override
        public void mouseClicked(MouseEvent event) {
            try {
                graph.addNode(new Graph2DNode(getNodeName("Enter Node Name", 
                        "Add Node"), event.getX(), event.getY()));
                drawPanel.repaint();
            }
            catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), 
                        "Wrong Input", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /*
    * Prompts to get the node name from the user
    */
    private char getNodeName(String message, String title) {
        char name = 0;
        boolean toRenter = false;
        do {
            try {                
                String input = JOptionPane.showInputDialog(null, message, title, 
                        QUESTION_MESSAGE);
                name = input.charAt(0);
                toRenter = false;
            }
            catch (IndexOutOfBoundsException | NullPointerException e) {
                int option = JOptionPane.showConfirmDialog(null, 
                        "Wrong Input: Would you like to try again?");
                if(option == JOptionPane.YES_OPTION) {
                    toRenter = true;
                }
                else {
                    throw new IllegalArgumentException("No Valid Input");
                }
            }
        } while(toRenter);
        
        return name;
    }
    
    
}
