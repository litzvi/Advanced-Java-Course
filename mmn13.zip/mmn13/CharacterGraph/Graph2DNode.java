/*
 * Represents a Graph node with a 2D location.
 */
package charactergraph;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class Graph2DNode extends GraphNode {
    
    //represents node location on 2D.
    private int x, y;
    
    //Construotur
    public Graph2DNode(char name, int x, int y){
        super(name);
        this.x = x;
        this.y = y;
    }
    
    // Creates a deep copy
    public Graph2DNode(Graph2DNode node){
        this(node.getName(), node.getX(), node.getY());
    }
    
    //returns location on x axis
    public int getX(){
        return x;
    }
    
    //returns location on y axis
    public int getY() {
        return y;
    }
    
}
