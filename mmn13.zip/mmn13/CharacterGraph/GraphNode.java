/*
 * Class that represents a graph node that has a name.
 */
package charactergraph;

/**
 *
 * @author Tzvi Lieberman i.d. 052821972
 */
public class GraphNode implements Comparable<GraphNode> {
    private final char name;
    
    //Constroctur
    public GraphNode(char name){
        this.name = name;
    }
    
    // Creates a deep copy
    public GraphNode(GraphNode node){
        this(node.getName());
    }
    
    //Returns graph node name
    public char getName(){
        return name;
    }
    
    
    //Returns true if they both have the same name
    @Override
    public boolean equals(Object node){
        if(!(node instanceof GraphNode)) {
            return false;
        }
        GraphNode graphNode = (GraphNode)node;
        return graphNode.getName() == getName();
    }

    /*
    * The comparison is based on the Unicode value of each character
    * negative if Unicode value precedes the argument,
    * positive if follows the argument and 0 if equal.
    */
    @Override
    public int compareTo(GraphNode node) {
        return getName() - node.getName();
    }
    
    @Override
    public String toString() {
        return Character.toString(getName());
    }
    
}
